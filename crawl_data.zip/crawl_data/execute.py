from scrapy.cmdline import execute
execute()